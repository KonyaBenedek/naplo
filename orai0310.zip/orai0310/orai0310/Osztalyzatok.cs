﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace orai0310
{
    public class Osztalyzatok
    {
        String nev;
        String datum;
        String tantargy;
        int jegy;

        public Osztalyzatok(string nev, string datum, string tantargy, int jegy)
        {
            this.nev = nev;
            this.datum = datum;
            this.tantargy = tantargy;
            this.jegy = jegy;
        }

        public string Nev { get => nev;}
        public string Datum { get => datum;}
        public string Tantargy { get => tantargy;}
        public int Jegy { get => jegy;}
    }
}
