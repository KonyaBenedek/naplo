﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace orai0310
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>


    public partial class MainWindow : Window
    {
        string fajlNev = "naplo.txt";
        List<Osztalyzatok> jegyek = new List<Osztalyzatok>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void OsztalyzatokBetoltese(string fajlNev)
        {
            jegyek.Clear();
            StreamReader sr = new StreamReader(fajlNev);
            while (!sr.EndOfStream)
            {
                string[] mezok = sr.ReadLine().Split(";");

                Osztalyzatok ujJegy = new Osztalyzatok(mezok[0], mezok[1], mezok[2], int.Parse(mezok[3]));

                jegyek.Add(ujJegy);
            }
            sr.Close();
            dgJegyek.ItemsSource = jegyek;
            MessageBox.Show("Az állomány beolvasása befejeződött!");
        }

        private void sliJegy_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lblErtek.Content = sliJegy.Value;
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            var save = ($"{txtNev.Text};{cboTantargy.SelectedItem};{dpDatum.Text};{sliJegy.Value}");

            StreamWriter sw = new StreamWriter("naplo.csv", append: true);
            sw.WriteLine(save);
            sw.Close();
            MessageBox.Show("Az adatok sikeresen rögzítve lettek.");
        }

        private void btnTolt_Click(object sender, RoutedEventArgs e)
        {
            OsztalyzatokBetoltese(fajlNev);
        }
    }
}
